# SocialFlow — Full Stack Social Media Downloader

Complete Flutter + Dart backend app for downloading videos and audio from social media.

## Supported Platforms
YouTube • Instagram • Facebook • TikTok • X (Twitter) • Threads • Pinterest • Vimeo • Dailymotion

---

## 📋 Requirements

| Tool | Version |
|------|---------|
| Flutter | 3.16+ |
| Dart | 3.2+ |
| yt-dlp | Latest |

---

## ⚡ Quick Setup (3 Steps)

### Step 1 — Install yt-dlp (for real downloads)

**Windows:**
```powershell
winget install yt-dlp
# OR
pip install yt-dlp
```

**macOS:**
```bash
brew install yt-dlp
# OR
pip install yt-dlp
```

**Linux:**
```bash
sudo pip install yt-dlp
# OR
sudo apt install yt-dlp
```

---

### Step 2 — Start Backend

```bash
cd backend
dart pub get
dart run server.dart
```

Backend will start at: **http://localhost:8080**

You should see:
```
✅ SocialFlow Backend running at http://localhost:8080
📁 Downloads folder: /Users/you/Downloads/SocialFlow
```

---

### Step 3 — Run Flutter App

Open a **new terminal window:**

```bash
cd flutter_app
flutter pub get
flutter run
```

For specific device:
```bash
flutter run -d android   # Android emulator/device
flutter run -d ios       # iOS simulator/device
flutter run -d chrome    # Web browser
```

---

## 📱 Device Connection

Edit `flutter_app/lib/core/api_client.dart` line 10:

| Device Type | Backend URL |
|-------------|-------------|
| Android Emulator | `http://10.0.2.2:8080` ✅ (default) |
| Physical Android (WiFi) | `http://<YOUR_PC_IP>:8080` |
| iOS Simulator | `http://localhost:8080` |

**Or change it in the app:** Settings → Backend Server URL

---

## 📁 Project Structure

```
socialflow/
├── backend/                    # Dart Shelf backend
│   ├── server.dart             # Entry point
│   ├── pubspec.yaml
│   └── lib/
│       ├── models.dart         # Data models
│       ├── database.dart       # SQLite operations
│       └── handlers/
│           ├── analyze_handler.dart    # URL analysis via yt-dlp
│           ├── download_handler.dart   # Download management
│           └── settings_handler.dart  # App settings
│
├── flutter_app/                # Flutter frontend
│   ├── lib/
│   │   ├── main.dart           # Entry point
│   │   ├── core/
│   │   │   ├── theme.dart      # Material 3 themes
│   │   │   └── api_client.dart # Dio HTTP client
│   │   ├── models/
│   │   │   └── models.dart     # Data classes
│   │   ├── providers/
│   │   │   └── providers.dart  # Riverpod state
│   │   ├── screens/
│   │   │   ├── home_screen.dart
│   │   │   ├── downloads_screen.dart
│   │   │   └── settings_screen.dart
│   │   └── widgets/
│   │       └── widgets.dart    # Reusable widgets
│   └── pubspec.yaml
│
└── README.md
```

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/healthz` | Health check |
| POST | `/api/analyze` | Analyze URL → media info |
| POST | `/api/download` | Start download |
| GET | `/api/downloads` | List all downloads |
| PATCH | `/api/downloads/:id` | Pause/Resume/Cancel/Retry |
| DELETE | `/api/downloads/:id` | Delete one record |
| DELETE | `/api/downloads` | Clear all history |
| GET | `/api/settings` | Get settings |
| PUT | `/api/settings` | Update settings |

---

## 🎯 Features

- ✅ Real video/audio download via yt-dlp
- ✅ Download quality: 144p, 240p, 360p, 480p, 720p, 1080p, MP3, M4A
- ✅ Real-time progress bar
- ✅ Pause, Resume, Cancel, Retry
- ✅ Download history with SQLite
- ✅ Dark Mode / Light Mode / System
- ✅ Material 3 UI
- ✅ Settings persistence
- ✅ Fake ads (for demonstration)
- ✅ Premium banner
- ✅ Error messages for unsupported URLs

---

## ⚠️ Troubleshooting

**"Cannot connect to backend"**
→ Make sure `dart run server.dart` is running in the `backend/` folder.

**"Download failed"**
→ Make sure yt-dlp is installed: run `yt-dlp --version` in terminal.
→ Update yt-dlp: `pip install -U yt-dlp`

**Android physical device can't connect**
→ Find your PC IP: `ipconfig` (Windows) or `ifconfig` (Mac/Linux)
→ Update backend URL in Settings → Backend Server URL to `http://<PC_IP>:8080`

**iOS simulator not connecting**
→ Change backend URL to `http://localhost:8080`
