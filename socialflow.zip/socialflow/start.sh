#!/bin/bash
# SocialFlow Quick Start Script

echo "🚀 SocialFlow - Starting Backend..."
echo ""

# Check yt-dlp
if ! command -v yt-dlp &> /dev/null; then
    echo "⚠️  yt-dlp is not installed."
    echo "   Install it with: pip install yt-dlp"
    echo "   Downloads will use simulation mode."
    echo ""
fi

# Start backend
cd backend
dart pub get
echo ""
echo "✅ Backend starting on http://localhost:8080"
echo ""
dart run server.dart
