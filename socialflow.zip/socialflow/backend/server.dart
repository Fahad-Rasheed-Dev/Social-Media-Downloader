import 'dart:io';
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as io;
import 'package:shelf_router/shelf_router.dart';
import 'package:shelf_cors_headers/shelf_cors_headers.dart';
import 'lib/database.dart';
import 'lib/handlers/analyze_handler.dart';
import 'lib/handlers/download_handler.dart';
import 'lib/handlers/settings_handler.dart';

void main() async {
  // Init DB
  initDatabase();

  // Default download folder
  final downloadFolder = getSettingVal();

  final router = Router();

  // Health
  router.get('/api/healthz', (Request req) {
    return Response.ok('{"status":"ok"}', headers: {'content-type': 'application/json'});
  });

  // Analyze
  router.post('/api/analyze', analyzeHandler);

  // Downloads
  router.post('/api/download', (Request req) => startDownloadHandler(req, downloadFolder));
  router.get('/api/downloads', listDownloadsHandler);
  router.delete('/api/downloads', clearDownloadsHandler);
  router.get('/api/downloads/<id>', (Request req, String id) => getDownloadHandler(req, id));
  router.patch('/api/downloads/<id>', (Request req, String id) => updateDownloadHandler(req, id));
  router.delete('/api/downloads/<id>', (Request req, String id) => deleteDownloadHandler(req, id));

  // Settings
  router.get('/api/settings', getSettingsHandler);
  router.put('/api/settings', updateSettingsHandler);

  final handler = const Pipeline()
      .addMiddleware(corsHeaders())
      .addMiddleware(logRequests())
      .addHandler(router.call);

  final port = int.tryParse(Platform.environment['PORT'] ?? '') ?? 8080;
  final server = await io.serve(handler, '0.0.0.0', port);
  print('✅ SocialFlow Backend running at http://localhost:${server.port}');
  print('📁 Downloads folder: $downloadFolder');
}

String getSettingVal() {
  final saved = getSetting('downloadFolder');
  if (saved != null && saved.isNotEmpty) return saved;

  String folder;
  if (Platform.isWindows) {
    final userProfile = Platform.environment['USERPROFILE'] ?? 'C:\\Users\\User';
    folder = '$userProfile\\Downloads\\SocialFlow';
  } else if (Platform.isMacOS) {
    final home = Platform.environment['HOME'] ?? '/Users/user';
    folder = '$home/Downloads/SocialFlow';
  } else {
    folder = '${Platform.environment['HOME'] ?? ''}/Downloads/SocialFlow';
  }

  setSetting('downloadFolder', folder);
  return folder;
}
