class MediaQuality {
  final String label;
  final String value;
  final String fileSize;
  final String type; // 'video' or 'audio'

  const MediaQuality({
    required this.label,
    required this.value,
    required this.fileSize,
    required this.type,
  });

  Map<String, dynamic> toJson() => {
        'label': label,
        'value': value,
        'fileSize': fileSize,
        'type': type,
      };
}

class MediaInfo {
  final String url;
  final String title;
  final String thumbnail;
  final String duration;
  final String platform;
  final String? uploader;
  final int? viewCount;
  final List<MediaQuality> qualities;

  const MediaInfo({
    required this.url,
    required this.title,
    required this.thumbnail,
    required this.duration,
    required this.platform,
    this.uploader,
    this.viewCount,
    required this.qualities,
  });

  Map<String, dynamic> toJson() => {
        'url': url,
        'title': title,
        'thumbnail': thumbnail,
        'duration': duration,
        'platform': platform,
        if (uploader != null) 'uploader': uploader,
        if (viewCount != null) 'viewCount': viewCount,
        'qualities': qualities.map((q) => q.toJson()).toList(),
      };
}

class DownloadRecord {
  final String id;
  final String url;
  final String title;
  final String thumbnail;
  final String platform;
  final String quality;
  final String qualityLabel;
  final String mediaType; // 'video' or 'audio'
  String status; // pending, downloading, paused, completed, failed, cancelled
  double progress;
  String? filePath;
  String? fileSize;
  String? errorMessage;
  final String createdAt;
  String updatedAt;

  DownloadRecord({
    required this.id,
    required this.url,
    required this.title,
    required this.thumbnail,
    required this.platform,
    required this.quality,
    required this.qualityLabel,
    required this.mediaType,
    this.status = 'pending',
    this.progress = 0,
    this.filePath,
    this.fileSize,
    this.errorMessage,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'url': url,
        'title': title,
        'thumbnail': thumbnail,
        'platform': platform,
        'quality': quality,
        'qualityLabel': qualityLabel,
        'mediaType': mediaType,
        'status': status,
        'progress': progress,
        if (filePath != null) 'filePath': filePath,
        if (fileSize != null) 'fileSize': fileSize,
        if (errorMessage != null) 'errorMessage': errorMessage,
        'createdAt': createdAt,
        'updatedAt': updatedAt,
      };

  factory DownloadRecord.fromJson(Map<String, dynamic> j) => DownloadRecord(
        id: j['id'] as String,
        url: j['url'] as String,
        title: j['title'] as String,
        thumbnail: j['thumbnail'] as String,
        platform: j['platform'] as String,
        quality: j['quality'] as String,
        qualityLabel: j['qualityLabel'] as String,
        mediaType: j['mediaType'] as String,
        status: j['status'] as String,
        progress: (j['progress'] as num).toDouble(),
        filePath: j['filePath'] as String?,
        fileSize: j['fileSize'] as String?,
        errorMessage: j['errorMessage'] as String?,
        createdAt: j['createdAt'] as String,
        updatedAt: j['updatedAt'] as String,
      );
}

class AppSettings {
  String theme;
  String language;
  String downloadFolder;
  int autoDeleteDays;
  bool notificationsEnabled;
  bool fakeAdsEnabled;
  String defaultQuality;

  AppSettings({
    this.theme = 'system',
    this.language = 'en',
    this.downloadFolder = '',
    this.autoDeleteDays = 0,
    this.notificationsEnabled = true,
    this.fakeAdsEnabled = true,
    this.defaultQuality = '720p',
  });

  Map<String, dynamic> toJson() => {
        'theme': theme,
        'language': language,
        'downloadFolder': downloadFolder,
        'autoDeleteDays': autoDeleteDays,
        'notificationsEnabled': notificationsEnabled,
        'fakeAdsEnabled': fakeAdsEnabled,
        'defaultQuality': defaultQuality,
      };

  factory AppSettings.fromJson(Map<String, dynamic> j) => AppSettings(
        theme: j['theme'] as String? ?? 'system',
        language: j['language'] as String? ?? 'en',
        downloadFolder: j['downloadFolder'] as String? ?? '',
        autoDeleteDays: j['autoDeleteDays'] as int? ?? 0,
        notificationsEnabled: j['notificationsEnabled'] as bool? ?? true,
        fakeAdsEnabled: j['fakeAdsEnabled'] as bool? ?? true,
        defaultQuality: j['defaultQuality'] as String? ?? '720p',
      );
}
