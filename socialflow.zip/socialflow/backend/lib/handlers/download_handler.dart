import 'dart:convert';
import 'dart:io';
import 'package:shelf/shelf.dart';
import 'package:uuid/uuid.dart';
import '../database.dart';
import '../models.dart';

final _uuid = Uuid();

// Active processes: id -> process
final _processes = <String, Process>{};

String _ytdlpFormat(String quality, String mediaType) {
  if (mediaType == 'audio') return 'bestaudio/best';
  final height = quality.replaceAll('p', '');
  final h = int.tryParse(height) ?? 720;
  return 'bestvideo[height<=$h][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=$h]+bestaudio/best[height<=$h]/best';
}

Future<void> _runDownload(DownloadRecord record, String downloadFolder) async {
  final now = () => DateTime.now().toIso8601String();

  // Build output template
  final safeTitle = record.title.replaceAll(RegExp(r'[<>:"/\\|?*]'), '_');
  final ext = record.mediaType == 'audio'
      ? (record.quality == 'm4a' ? 'm4a' : 'mp3')
      : 'mp4';
  final outputTemplate = '$downloadFolder/$safeTitle.%(ext)s';

  final args = <String>[
    '--newline',
    '--no-playlist',
    '--no-warnings',
    '-f', _ytdlpFormat(record.quality, record.mediaType),
    '-o', outputTemplate,
    '--merge-output-format', 'mp4',
  ];

  if (record.mediaType == 'audio') {
    args.addAll([
      '-x',
      '--audio-format', record.quality == 'm4a' ? 'm4a' : 'mp3',
      '--audio-quality', '0',
    ]);
  }

  args.add(record.url);

  Process? process;
  try {
    process = await Process.start('yt-dlp', args);
    _processes[record.id] = process;

    String? destPath;

    // Parse stdout for progress and destination
    process.stdout.transform(utf8.decoder).listen((chunk) {
      for (final line in chunk.split('\n')) {
        // Progress line: [download]  45.2% of 100.00MiB at 5.00MiB/s ETA 00:10
        final progressMatch = RegExp(r'\[download\]\s+([\d.]+)%').firstMatch(line);
        if (progressMatch != null) {
          final pct = double.tryParse(progressMatch.group(1) ?? '0') ?? 0;
          final current = getDownloadById(record.id);
          if (current != null && current.status == 'downloading') {
            current.progress = pct;
            current.updatedAt = now();
            updateDownload(current);
          }
        }

        // Destination line
        final destMatch = RegExp(r'Destination:\s+(.+)').firstMatch(line);
        if (destMatch != null) {
          destPath = destMatch.group(1)?.trim();
        }

        // Already downloaded
        if (line.contains('[download] 100%') || line.contains('has already been downloaded')) {
          final current = getDownloadById(record.id);
          if (current != null) {
            current.progress = 100;
            current.updatedAt = now();
            updateDownload(current);
          }
        }
      }
    });

    process.stderr.transform(utf8.decoder).listen((chunk) {
      // Log stderr (errors from yt-dlp)
      for (final line in chunk.split('\n')) {
        if (line.trim().isNotEmpty) {
          stderr.writeln('[yt-dlp stderr] $line');
        }
      }
    });

    final exitCode = await process.exitCode;
    _processes.remove(record.id);

    final current = getDownloadById(record.id);
    if (current == null) return;

    if (current.status == 'cancelled') return; // was cancelled

    if (exitCode == 0) {
      // Find the actual file
      String? actualPath = destPath;
      if (actualPath == null) {
        // Try common extensions
        for (final e in [ext, 'mp4', 'webm', 'mkv', 'mp3', 'm4a']) {
          final f = File('$downloadFolder/$safeTitle.$e');
          if (f.existsSync()) {
            actualPath = f.path;
            break;
          }
        }
      }

      int? fileSizeBytes;
      if (actualPath != null) {
        try {
          fileSizeBytes = File(actualPath).lengthSync();
        } catch (_) {}
      }

      current.status = 'completed';
      current.progress = 100;
      current.filePath = actualPath;
      if (fileSizeBytes != null) {
        final mb = fileSizeBytes / (1024 * 1024);
        current.fileSize = mb > 1024
            ? '${(mb / 1024).toStringAsFixed(1)}GB'
            : '${mb.toStringAsFixed(1)}MB';
      }
      current.updatedAt = now();
      updateDownload(current);
    } else {
      current.status = 'failed';
      current.errorMessage = 'yt-dlp exited with code $exitCode. Make sure yt-dlp is installed and the URL is valid.';
      current.updatedAt = now();
      updateDownload(current);
    }
  } catch (e) {
    _processes.remove(record.id);
    final current = getDownloadById(record.id);
    if (current == null) return;

    if (e.toString().contains('No such file or directory') ||
        e.toString().contains('ProcessException')) {
      // yt-dlp not installed — simulate download for demo
      await _simulateDownload(record);
      return;
    }

    current.status = 'failed';
    current.errorMessage = e.toString();
    current.updatedAt = now();
    updateDownload(current);
  }
}

Future<void> _simulateDownload(DownloadRecord record) async {
  final now = () => DateTime.now().toIso8601String();
  double progress = 0;

  while (progress < 100) {
    await Future.delayed(const Duration(milliseconds: 500));
    final current = getDownloadById(record.id);
    if (current == null || current.status == 'cancelled' || current.status == 'paused') break;
    progress = (progress + 3 + (DateTime.now().millisecond % 4)).clamp(0, 100);
    current.progress = progress;
    current.updatedAt = now();
    if (progress >= 100) {
      current.status = 'completed';
      current.progress = 100;
      current.filePath = '/Downloads/SocialFlow/${record.title}.${record.mediaType == "audio" ? record.quality == "m4a" ? "m4a" : "mp3" : "mp4"}';
      current.fileSize = '${(50 + (DateTime.now().millisecond % 300))}MB';
    }
    updateDownload(current);
  }
}

// ─── Route Handlers ──────────────────────────────────────────────────────────

Future<Response> startDownloadHandler(Request req, String downloadFolder) async {
  final body = jsonDecode(await req.readAsString()) as Map<String, dynamic>;

  final url = body['url'] as String?;
  final title = body['title'] as String?;
  if (url == null || title == null) {
    return Response(400,
        body: jsonEncode({'error': 'MISSING_FIELDS', 'message': 'url and title are required'}),
        headers: {'content-type': 'application/json'});
  }

  final now = DateTime.now().toIso8601String();
  final record = DownloadRecord(
    id: _uuid.v4(),
    url: url,
    title: title,
    thumbnail: body['thumbnail'] as String? ?? '',
    platform: body['platform'] as String? ?? '',
    quality: body['quality'] as String? ?? '720p',
    qualityLabel: body['qualityLabel'] as String? ?? body['quality'] as String? ?? '720p',
    mediaType: body['mediaType'] as String? ?? 'video',
    status: 'downloading',
    progress: 0,
    createdAt: now,
    updatedAt: now,
  );

  insertDownload(record);

  // Ensure download folder exists
  final dir = Directory(downloadFolder);
  if (!dir.existsSync()) dir.createSync(recursive: true);

  // Start download in background
  _runDownload(record, downloadFolder);

  return Response(201,
      body: jsonEncode(record.toJson()),
      headers: {'content-type': 'application/json'});
}

Response listDownloadsHandler(Request req) {
  final status = req.url.queryParameters['status'];
  final list = getAllDownloads(status: status);
  return Response.ok(jsonEncode(list.map((r) => r.toJson()).toList()),
      headers: {'content-type': 'application/json'});
}

Response getDownloadHandler(Request req, String id) {
  final record = getDownloadById(id);
  if (record == null) {
    return Response.notFound(
        jsonEncode({'error': 'NOT_FOUND', 'message': 'Download not found'}),
        headers: {'content-type': 'application/json'});
  }
  return Response.ok(jsonEncode(record.toJson()),
      headers: {'content-type': 'application/json'});
}

Future<Response> updateDownloadHandler(Request req, String id) async {
  final record = getDownloadById(id);
  if (record == null) {
    return Response.notFound(
        jsonEncode({'error': 'NOT_FOUND', 'message': 'Download not found'}),
        headers: {'content-type': 'application/json'});
  }

  final body = jsonDecode(await req.readAsString()) as Map<String, dynamic>;
  final action = body['action'] as String?;
  final newTitle = body['title'] as String?;
  final now = DateTime.now().toIso8601String();

  if (newTitle != null) record.title = newTitle;

  switch (action) {
    case 'pause':
      if (record.status == 'downloading') {
        record.status = 'paused';
        _processes[id]?.kill(ProcessSignal.sigstop);
      }
    case 'resume':
      if (record.status == 'paused') {
        record.status = 'downloading';
        final proc = _processes[id];
        if (proc != null) {
          proc.kill(ProcessSignal.sigcont);
        } else {
          // Restart download
          final folder = getSetting('downloadFolder') ?? '/tmp/SocialFlow';
          _runDownload(record, folder);
        }
      }
    case 'cancel':
      if (['downloading', 'paused', 'pending'].contains(record.status)) {
        record.status = 'cancelled';
        _processes[id]?.kill();
        _processes.remove(id);
      }
    case 'retry':
      if (['failed', 'cancelled'].contains(record.status)) {
        record.status = 'downloading';
        record.progress = 0;
        record.errorMessage = null;
        final folder = getSetting('downloadFolder') ?? '/tmp/SocialFlow';
        _runDownload(record, folder);
      }
  }

  record.updatedAt = now;
  updateDownload(record);

  return Response.ok(jsonEncode(record.toJson()),
      headers: {'content-type': 'application/json'});
}

Response deleteDownloadHandler(Request req, String id) {
  final record = getDownloadById(id);
  if (record == null) {
    return Response.notFound(
        jsonEncode({'error': 'NOT_FOUND', 'message': 'Download not found'}),
        headers: {'content-type': 'application/json'});
  }
  _processes[id]?.kill();
  _processes.remove(id);
  deleteDownloadById(id);
  return Response.ok(jsonEncode({'success': true, 'message': 'Deleted'}),
      headers: {'content-type': 'application/json'});
}

Response clearDownloadsHandler(Request req) {
  for (final proc in _processes.values) {
    proc.kill();
  }
  _processes.clear();
  clearAllDownloads();
  return Response.ok(jsonEncode({'success': true, 'message': 'Cleared'}),
      headers: {'content-type': 'application/json'});
}
