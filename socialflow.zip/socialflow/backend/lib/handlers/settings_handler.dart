import 'dart:convert';
import 'dart:io';
import 'package:shelf/shelf.dart';
import '../database.dart';
import '../models.dart';

AppSettings _loadSettings() {
  return AppSettings(
    theme: getSetting('theme') ?? 'system',
    language: getSetting('language') ?? 'en',
    downloadFolder: getSetting('downloadFolder') ?? _defaultDownloadFolder(),
    autoDeleteDays: int.tryParse(getSetting('autoDeleteDays') ?? '0') ?? 0,
    notificationsEnabled: (getSetting('notificationsEnabled') ?? 'true') == 'true',
    fakeAdsEnabled: (getSetting('fakeAdsEnabled') ?? 'true') == 'true',
    defaultQuality: getSetting('defaultQuality') ?? '720p',
  );
}

String _defaultDownloadFolder() {
  if (Platform.isWindows) {
    final userProfile = Platform.environment['USERPROFILE'] ?? 'C:\\Users\\User';
    return '$userProfile\\Downloads\\SocialFlow';
  }
  if (Platform.isMacOS) {
    final home = Platform.environment['HOME'] ?? '/Users/user';
    return '$home/Downloads/SocialFlow';
  }
  // Linux / Android
  return '${Platform.environment['HOME'] ?? ''}/Downloads/SocialFlow';
}

Response getSettingsHandler(Request req) {
  final settings = _loadSettings();
  return Response.ok(jsonEncode(settings.toJson()),
      headers: {'content-type': 'application/json'});
}

Future<Response> updateSettingsHandler(Request req) async {
  final body = jsonDecode(await req.readAsString()) as Map<String, dynamic>;

  if (body['theme'] != null) setSetting('theme', body['theme'] as String);
  if (body['language'] != null) setSetting('language', body['language'] as String);
  if (body['downloadFolder'] != null) setSetting('downloadFolder', body['downloadFolder'] as String);
  if (body['autoDeleteDays'] != null) setSetting('autoDeleteDays', body['autoDeleteDays'].toString());
  if (body['notificationsEnabled'] != null) setSetting('notificationsEnabled', body['notificationsEnabled'].toString());
  if (body['fakeAdsEnabled'] != null) setSetting('fakeAdsEnabled', body['fakeAdsEnabled'].toString());
  if (body['defaultQuality'] != null) setSetting('defaultQuality', body['defaultQuality'] as String);

  final settings = _loadSettings();
  return Response.ok(jsonEncode(settings.toJson()),
      headers: {'content-type': 'application/json'});
}
