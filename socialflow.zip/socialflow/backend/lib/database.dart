import 'dart:io';
import 'package:sqlite3/sqlite3.dart';
import 'package:path/path.dart' as p;
import 'models.dart';

late Database _db;

void initDatabase() {
  final dbDir = Directory(p.join(Directory.current.path, 'data'));
  if (!dbDir.existsSync()) dbDir.createSync(recursive: true);

  _db = sqlite3.open(p.join(dbDir.path, 'socialflow.db'));

  _db.execute('''
    CREATE TABLE IF NOT EXISTS downloads (
      id TEXT PRIMARY KEY,
      url TEXT NOT NULL,
      title TEXT NOT NULL,
      thumbnail TEXT DEFAULT '',
      platform TEXT DEFAULT '',
      quality TEXT DEFAULT '',
      quality_label TEXT DEFAULT '',
      media_type TEXT DEFAULT 'video',
      status TEXT DEFAULT 'pending',
      progress REAL DEFAULT 0,
      file_path TEXT,
      file_size TEXT,
      error_message TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  ''');

  _db.execute('''
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )
  ''');
}

// ─── Downloads ───────────────────────────────────────────────────────────────

void insertDownload(DownloadRecord r) {
  _db.execute(
    '''INSERT INTO downloads
       (id,url,title,thumbnail,platform,quality,quality_label,media_type,
        status,progress,file_path,file_size,error_message,created_at,updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
    [
      r.id, r.url, r.title, r.thumbnail, r.platform,
      r.quality, r.qualityLabel, r.mediaType,
      r.status, r.progress, r.filePath, r.fileSize, r.errorMessage,
      r.createdAt, r.updatedAt,
    ],
  );
}

void updateDownload(DownloadRecord r) {
  _db.execute(
    '''UPDATE downloads SET
       status=?, progress=?, file_path=?, file_size=?,
       error_message=?, updated_at=?
       WHERE id=?''',
    [r.status, r.progress, r.filePath, r.fileSize, r.errorMessage, r.updatedAt, r.id],
  );
}

void deleteDownloadById(String id) {
  _db.execute('DELETE FROM downloads WHERE id=?', [id]);
}

void clearAllDownloads() {
  _db.execute('DELETE FROM downloads');
}

List<DownloadRecord> getAllDownloads({String? status}) {
  final rows = status != null
      ? _db.select('SELECT * FROM downloads WHERE status=? ORDER BY created_at DESC', [status])
      : _db.select('SELECT * FROM downloads ORDER BY created_at DESC');
  return rows.map(_rowToRecord).toList();
}

DownloadRecord? getDownloadById(String id) {
  final rows = _db.select('SELECT * FROM downloads WHERE id=?', [id]);
  if (rows.isEmpty) return null;
  return _rowToRecord(rows.first);
}

DownloadRecord _rowToRecord(Row row) {
  return DownloadRecord(
    id: row['id'] as String,
    url: row['url'] as String,
    title: row['title'] as String,
    thumbnail: row['thumbnail'] as String? ?? '',
    platform: row['platform'] as String? ?? '',
    quality: row['quality'] as String? ?? '',
    qualityLabel: row['quality_label'] as String? ?? '',
    mediaType: row['media_type'] as String? ?? 'video',
    status: row['status'] as String,
    progress: (row['progress'] as num).toDouble(),
    filePath: row['file_path'] as String?,
    fileSize: row['file_size'] as String?,
    errorMessage: row['error_message'] as String?,
    createdAt: row['created_at'] as String,
    updatedAt: row['updated_at'] as String,
  );
}

// ─── Settings ─────────────────────────────────────────────────────────────────

String? getSetting(String key) {
  final rows = _db.select('SELECT value FROM settings WHERE key=?', [key]);
  if (rows.isEmpty) return null;
  return rows.first['value'] as String;
}

void setSetting(String key, String value) {
  _db.execute(
    'INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=?',
    [key, value, value],
  );
}
