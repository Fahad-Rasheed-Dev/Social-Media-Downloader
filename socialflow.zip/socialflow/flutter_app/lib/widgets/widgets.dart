import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import '../models/models.dart';

// ─── Glass Card ───────────────────────────────────────────────────────────────

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  final double? borderRadius;

  const GlassCard({super.key, required this.child, this.padding, this.borderRadius});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF14142B) : Colors.white,
        borderRadius: BorderRadius.circular(borderRadius ?? 16),
        border: Border.all(
          color: isDark
              ? const Color(0xFF7C3AED).withOpacity(0.2)
              : const Color(0xFF7C3AED).withOpacity(0.15),
        ),
      ),
      padding: padding ?? const EdgeInsets.all(16),
      child: child,
    );
  }
}

// ─── Platform Badge ───────────────────────────────────────────────────────────

const _platformColors = {
  'YouTube': Color(0xFFFF0000),
  'Instagram': Color(0xFFE1306C),
  'Facebook': Color(0xFF1877F2),
  'TikTok': Color(0xFFEE1D52),
  'X (Twitter)': Color(0xFF1DA1F2),
  'Threads': Color(0xFFA855F7),
  'Pinterest': Color(0xFFE60023),
  'Vimeo': Color(0xFF1AB7EA),
  'Dailymotion': Color(0xFF0066DC),
};

const _platformIcons = {
  'YouTube': Icons.play_circle_fill,
  'Instagram': Icons.camera_alt,
  'Facebook': Icons.facebook,
  'TikTok': Icons.music_note,
  'X (Twitter)': Icons.tag,
  'Threads': Icons.alternate_email,
  'Pinterest': Icons.push_pin,
  'Vimeo': Icons.videocam,
  'Dailymotion': Icons.smart_display,
};

class PlatformBadge extends StatelessWidget {
  final String platform;
  final bool small;

  const PlatformBadge({super.key, required this.platform, this.small = false});

  @override
  Widget build(BuildContext context) {
    final color = _platformColors[platform] ?? const Color(0xFF888888);
    final icon = _platformIcons[platform] ?? Icons.link;

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: small ? 6 : 9,
        vertical: small ? 2 : 4,
      ),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: small ? 10 : 12, color: color),
          const SizedBox(width: 4),
          Text(
            platform,
            style: TextStyle(
              color: color,
              fontSize: small ? 10 : 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Download Card ────────────────────────────────────────────────────────────

const _statusColors = {
  'pending': Color(0xFFF59E0B),
  'downloading': Color(0xFF06B6D4),
  'paused': Color(0xFFF59E0B),
  'completed': Color(0xFF10B981),
  'failed': Color(0xFFEF4444),
  'cancelled': Color(0xFF6B7280),
};

const _statusLabels = {
  'pending': 'Waiting',
  'downloading': 'Downloading',
  'paused': 'Paused',
  'completed': 'Completed',
  'failed': 'Failed',
  'cancelled': 'Cancelled',
};

class DownloadCard extends StatelessWidget {
  final DownloadItem download;
  final VoidCallback? onPause;
  final VoidCallback? onResume;
  final VoidCallback? onCancel;
  final VoidCallback? onRetry;
  final VoidCallback? onDelete;

  const DownloadCard({
    super.key,
    required this.download,
    this.onPause,
    this.onResume,
    this.onCancel,
    this.onRetry,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final statusColor = _statusColors[download.status] ?? const Color(0xFF888888);
    final statusLabel = _statusLabels[download.status] ?? download.status;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF14142B) : Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isDark ? const Color(0xFF2D2D4E) : const Color(0xFFE5E7EB),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Thumbnail
          ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(12),
              bottomLeft: Radius.circular(12),
            ),
            child: download.thumbnail.isNotEmpty
                ? CachedNetworkImage(
                    imageUrl: download.thumbnail,
                    width: 88,
                    height: 100,
                    fit: BoxFit.cover,
                    errorWidget: (_, __, ___) => _thumbPlaceholder(),
                  )
                : _thumbPlaceholder(),
          ),

          // Content
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title
                  Text(
                    download.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, height: 1.4),
                  ),
                  const SizedBox(height: 5),

                  // Badges
                  Wrap(
                    spacing: 5,
                    runSpacing: 4,
                    children: [
                      PlatformBadge(platform: download.platform, small: true),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: colorScheme.surfaceContainerHighest,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (download.mediaType == 'audio')
                              const Icon(Icons.music_note, size: 9),
                            if (download.mediaType == 'audio') const SizedBox(width: 2),
                            Text(
                              download.qualityLabel,
                              style: TextStyle(fontSize: 10, color: colorScheme.onSurfaceVariant),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),

                  // Progress bar
                  if (download.status == 'downloading' || download.status == 'paused')
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        LinearPercentIndicator(
                          percent: (download.progress / 100).clamp(0, 1),
                          lineHeight: 4,
                          padding: EdgeInsets.zero,
                          backgroundColor: isDark ? const Color(0xFF2D2D4E) : const Color(0xFFE5E7EB),
                          progressColor: download.status == 'paused'
                              ? const Color(0xFFF59E0B)
                              : const Color(0xFF06B6D4),
                          barRadius: const Radius.circular(2),
                          animation: false,
                        ),
                        const SizedBox(height: 3),
                        Text(
                          '${download.progress.toStringAsFixed(1)}%',
                          style: TextStyle(
                            fontSize: 10,
                            color: colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),

                  // Status + actions row
                  Row(
                    children: [
                      Container(
                        width: 5,
                        height: 5,
                        decoration: BoxDecoration(
                          color: statusColor,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        statusLabel,
                        style: TextStyle(fontSize: 11, color: statusColor, fontWeight: FontWeight.w500),
                      ),
                      if (download.fileSize != null && download.status == 'completed')
                        Text(
                          ' · ${download.fileSize}',
                          style: TextStyle(fontSize: 11, color: colorScheme.onSurfaceVariant),
                        ),
                      const Spacer(),
                      // Action buttons
                      if (download.status == 'downloading' && onPause != null)
                        _ActionBtn(icon: Icons.pause, onTap: onPause!),
                      if (download.status == 'paused' && onResume != null)
                        _ActionBtn(icon: Icons.play_arrow, onTap: onResume!),
                      if (download.isActive && onCancel != null)
                        _ActionBtn(icon: Icons.close, onTap: onCancel!, color: const Color(0xFFEF4444)),
                      if ((download.status == 'failed' || download.status == 'cancelled') && onRetry != null)
                        _ActionBtn(icon: Icons.refresh, onTap: onRetry!),
                      if (onDelete != null)
                        _ActionBtn(icon: Icons.delete_outline, onTap: onDelete!, color: const Color(0xFFEF4444)),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _thumbPlaceholder() => Container(
        width: 88,
        height: 100,
        color: const Color(0xFF1A1A2E),
        child: const Icon(Icons.movie, color: Color(0xFF6B7280), size: 28),
      );
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color? color;

  const _ActionBtn({required this.icon, required this.onTap, this.color});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 26,
        height: 26,
        margin: const EdgeInsets.only(left: 4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(7),
          border: Border.all(color: isDark ? const Color(0xFF2D2D4E) : const Color(0xFFE5E7EB)),
        ),
        child: Icon(icon, size: 13, color: color ?? Theme.of(context).colorScheme.primary),
      ),
    );
  }
}

// ─── Fake Ad Banner ───────────────────────────────────────────────────────────

class FakeAdBanner extends StatefulWidget {
  const FakeAdBanner({super.key});

  @override
  State<FakeAdBanner> createState() => _FakeAdBannerState();
}

class _FakeAdBannerState extends State<FakeAdBanner> {
  bool _dismissed = false;

  static const _ads = [
    _Ad('ProDownloader+', 'Download 10x faster. No limits.', 'Try Free',
        [Color(0xFF7C3AED), Color(0xFF3B82F6)]),
    _Ad('VaultSave Pro', 'Save everything. Access anywhere.', 'Get 50% Off',
        [Color(0xFFEC4899), Color(0xFFF97316)]),
    _Ad('StreamSaver', 'Unlimited HD downloads, zero ads.', 'Upgrade Now',
        [Color(0xFF10B981), Color(0xFF06B6D4)]),
  ];

  late final _Ad _ad;

  @override
  void initState() {
    super.initState();
    _ad = _ads[DateTime.now().millisecond % _ads.length];
  }

  @override
  Widget build(BuildContext context) {
    if (_dismissed) return const SizedBox.shrink();
    return Column(
      children: [
        Text('AD', style: TextStyle(fontSize: 9, color: Colors.grey[500], letterSpacing: 1)),
        const SizedBox(height: 3),
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: _ad.colors, begin: Alignment.centerLeft, end: Alignment.centerRight),
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_ad.brand, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                    Text(_ad.tagline, style: const TextStyle(color: Colors.white70, fontSize: 11)),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.22),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.white38),
                ),
                child: Text(_ad.cta, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () => setState(() => _dismissed = true),
                child: Container(
                  width: 18,
                  height: 18,
                  decoration: BoxDecoration(
                    color: Colors.black26,
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: const Icon(Icons.close, size: 11, color: Colors.white70),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _Ad {
  final String brand, tagline, cta;
  final List<Color> colors;
  const _Ad(this.brand, this.tagline, this.cta, this.colors);
}

// ─── Gradient Button ──────────────────────────────────────────────────────────

class GradientButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final bool loading;

  const GradientButton({
    super.key,
    required this.label,
    this.icon,
    this.onPressed,
    this.loading = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: AnimatedOpacity(
        opacity: onPressed == null || loading ? 0.6 : 1.0,
        duration: const Duration(milliseconds: 200),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF7C3AED), Color(0xFF3B82F6), Color(0xFF06B6D4)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (loading)
                const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                )
              else if (icon != null)
                Icon(icon, color: Colors.white, size: 18),
              if (!loading) const SizedBox(width: 8),
              Text(
                loading ? 'Please wait...' : label,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
