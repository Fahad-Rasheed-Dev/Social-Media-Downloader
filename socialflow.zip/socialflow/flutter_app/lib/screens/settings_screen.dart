import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../core/api_client.dart';

const _appVersion = '1.0.0';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settingsAsync = ref.watch(settingsProvider);
    final themeMode = ref.watch(themeProvider);
    final themeNotifier = ref.read(themeProvider.notifier);
    final backendUrl = ref.watch(backendUrlProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 22)),
      ),
      body: settingsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.wifi_off, size: 48, color: Colors.grey),
              const SizedBox(height: 12),
              const Text('Cannot connect to backend'),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => ref.read(settingsProvider.notifier).load(),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
        data: (settings) {
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
            children: [
              // ── Appearance ────────────────────────────────────────
              _SectionHeader('APPEARANCE'),
              _SettingsCard(children: [
                _TileRow(
                  icon: Icons.brightness_medium,
                  iconColor: const Color(0xFFF59E0B),
                  label: 'Theme',
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      for (final opt in [('light', 'Light', Icons.wb_sunny), ('dark', 'Dark', Icons.nightlight_round), ('system', 'System', Icons.phone_android)])
                        Padding(
                          padding: const EdgeInsets.only(left: 5),
                          child: GestureDetector(
                            onTap: () {
                              themeNotifier.setTheme(opt.$1);
                              _updateSetting(ref, settings.copyWith(theme: opt.$1));
                            },
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 150),
                              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                              decoration: BoxDecoration(
                                color: themeNotifier.currentString == opt.$1
                                    ? const Color(0xFF7C3AED)
                                    : Theme.of(context).colorScheme.surfaceContainerHighest,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: themeNotifier.currentString == opt.$1
                                      ? const Color(0xFF7C3AED)
                                      : Colors.grey.withOpacity(0.3),
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(opt.$3, size: 12, color: themeNotifier.currentString == opt.$1 ? Colors.white : Colors.grey),
                                  const SizedBox(width: 4),
                                  Text(opt.$2, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: themeNotifier.currentString == opt.$1 ? Colors.white : null)),
                                ],
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                _TileRow(
                  icon: Icons.language,
                  iconColor: const Color(0xFF06B6D4),
                  label: 'Language',
                  subtitle: _langLabel(settings.language),
                  isLast: true,
                  onTap: () => _showLanguagePicker(context, ref, settings),
                ),
              ]),
              const SizedBox(height: 16),

              // ── Downloads ─────────────────────────────────────────
              _SectionHeader('DOWNLOADS'),
              _SettingsCard(children: [
                _TileRow(
                  icon: Icons.high_quality,
                  iconColor: const Color(0xFF7C3AED),
                  label: 'Default Quality',
                  subtitle: settings.defaultQuality,
                  onTap: () => _showQualityPicker(context, ref, settings),
                ),
                _TileRow(
                  icon: Icons.folder_outlined,
                  iconColor: const Color(0xFFF59E0B),
                  label: 'Download Folder',
                  subtitle: settings.downloadFolder.isNotEmpty ? settings.downloadFolder : '/Downloads/SocialFlow',
                  isLast: true,
                ),
              ]),
              const SizedBox(height: 16),

              // ── Backend ───────────────────────────────────────────
              _SectionHeader('BACKEND'),
              _SettingsCard(children: [
                _TileRow(
                  icon: Icons.dns_outlined,
                  iconColor: const Color(0xFF10B981),
                  label: 'Server URL',
                  subtitle: backendUrl,
                  onTap: () => _showBackendUrlDialog(context, ref, backendUrl),
                  isLast: true,
                ),
              ]),
              const SizedBox(height: 16),

              // ── Privacy & Display ─────────────────────────────────
              _SectionHeader('PRIVACY & DISPLAY'),
              _SettingsCard(children: [
                _TileRow(
                  icon: Icons.notifications_outlined,
                  iconColor: const Color(0xFF06B6D4),
                  label: 'Notifications',
                  trailing: Switch(
                    value: settings.notificationsEnabled,
                    onChanged: (v) => _updateSetting(ref, settings.copyWith(notificationsEnabled: v)),
                    activeColor: const Color(0xFF7C3AED),
                  ),
                ),
                _TileRow(
                  icon: Icons.ad_units_outlined,
                  iconColor: const Color(0xFFF59E0B),
                  label: 'Show Ads',
                  trailing: Switch(
                    value: settings.fakeAdsEnabled,
                    onChanged: (v) => _updateSetting(ref, settings.copyWith(fakeAdsEnabled: v)),
                    activeColor: const Color(0xFF7C3AED),
                  ),
                  isLast: true,
                ),
              ]),
              const SizedBox(height: 16),

              // ── About ─────────────────────────────────────────────
              _SectionHeader('ABOUT'),
              _SettingsCard(children: [
                _TileRow(icon: Icons.info_outline, iconColor: const Color(0xFF7C3AED), label: 'About SocialFlow', onTap: () => _showAbout(context)),
                _TileRow(icon: Icons.shield_outlined, iconColor: const Color(0xFF10B981), label: 'Privacy Policy', onTap: () => _showPrivacy(context)),
                _TileRow(icon: Icons.article_outlined, iconColor: Colors.grey, label: 'Terms of Service', onTap: () => _showTerms(context), isLast: true),
              ]),
              const SizedBox(height: 16),

              // Premium card
              Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF7C3AED), Color(0xFF06B6D4)]),
                  borderRadius: BorderRadius.circular(16),
                ),
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.bolt, color: Colors.white, size: 22),
                        SizedBox(width: 8),
                        Text('Go Premium', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    const Text('Unlimited downloads · No ads · HD priority', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton(
                        onPressed: () {},
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(color: Colors.white38),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: const Text('Upgrade Free', style: TextStyle(fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Center(
                child: Text('SocialFlow v$_appVersion', style: const TextStyle(color: Colors.grey, fontSize: 12)),
              ),
            ],
          );
        },
      ),
    );
  }

  String _langLabel(String code) {
    const langs = {'en': 'English', 'es': 'Español', 'fr': 'Français', 'de': 'Deutsch', 'ja': '日本語', 'zh': '中文'};
    return langs[code] ?? code;
  }

  void _updateSetting(WidgetRef ref, AppSettings s) {
    ref.read(settingsProvider.notifier).update(s);
  }

  void _showQualityPicker(BuildContext context, WidgetRef ref, AppSettings settings) {
    final opts = ['144p', '240p', '360p', '480p', '720p', '1080p', 'mp3', 'm4a'];
    showModalBottomSheet(
      context: context,
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(padding: EdgeInsets.all(16), child: Text('Default Quality', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
          ...opts.map((q) => ListTile(
            title: Text(q),
            trailing: settings.defaultQuality == q ? const Icon(Icons.check, color: Color(0xFF7C3AED)) : null,
            onTap: () {
              _updateSetting(ref, settings.copyWith(defaultQuality: q));
              Navigator.pop(context);
            },
          )),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  void _showLanguagePicker(BuildContext context, WidgetRef ref, AppSettings settings) {
    const langs = [('en', 'English'), ('es', 'Español'), ('fr', 'Français'), ('de', 'Deutsch'), ('ja', '日本語'), ('zh', '中文')];
    showModalBottomSheet(
      context: context,
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(padding: EdgeInsets.all(16), child: Text('Language', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
          ...langs.map((l) => ListTile(
            title: Text(l.$2),
            trailing: settings.language == l.$1 ? const Icon(Icons.check, color: Color(0xFF7C3AED)) : null,
            onTap: () {
              _updateSetting(ref, settings.copyWith(language: l.$1));
              Navigator.pop(context);
            },
          )),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  void _showBackendUrlDialog(BuildContext context, WidgetRef ref, String current) {
    final ctrl = TextEditingController(text: current);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Backend Server URL'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(controller: ctrl, decoration: const InputDecoration(hintText: 'http://10.0.2.2:8080')),
            const SizedBox(height: 8),
            const Text('• Android Emulator: http://10.0.2.2:8080\n• Physical Device: http://<PC_IP>:8080\n• iOS Simulator: http://localhost:8080', style: TextStyle(fontSize: 11, color: Colors.grey)),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final url = ctrl.text.trim();
              if (url.isNotEmpty) {
                ApiClient.setBaseUrl(url);
                ref.read(backendUrlProvider.notifier).setUrl(url);
                ref.read(settingsProvider.notifier).load();
                ref.read(downloadsProvider.notifier).load();
              }
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showAbout(BuildContext context) {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('About SocialFlow'),
      content: const Text('SocialFlow v$_appVersion\n\nA powerful social media downloader supporting YouTube, Instagram, TikTok, Facebook, X, Threads, Pinterest, Vimeo, and Dailymotion.\n\nPowered by yt-dlp for real downloads.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
    ));
  }

  void _showPrivacy(BuildContext context) {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Privacy Policy'),
      content: const Text('SocialFlow does not collect any personal data. All downloads are stored locally on your device. No analytics or tracking are used.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
    ));
  }

  void _showTerms(BuildContext context) {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Terms of Service'),
      content: const Text('SocialFlow is for personal use only. Please respect copyright laws and platform terms of service when downloading content. The developers are not responsible for misuse.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
    ));
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(left: 4, bottom: 6),
    child: Text(title, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Colors.grey[500], letterSpacing: 0.8)),
  );
}

class _SettingsCard extends StatelessWidget {
  final List<Widget> children;
  const _SettingsCard({required this.children});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF14142B) : Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: isDark ? const Color(0xFF2D2D4E) : const Color(0xFFE5E7EB), width: 0.5),
      ),
      child: Column(children: children),
    );
  }
}

class _TileRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  final bool isLast;

  const _TileRow({
    required this.icon,
    required this.iconColor,
    required this.label,
    this.subtitle,
    this.trailing,
    this.onTap,
    this.isLast = false,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        decoration: BoxDecoration(
          border: isLast ? null : Border(bottom: BorderSide(color: isDark ? const Color(0xFF2D2D4E) : const Color(0xFFE5E7EB), width: 0.5)),
        ),
        child: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(color: iconColor.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
              child: Icon(icon, size: 16, color: iconColor),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500)),
                  if (subtitle != null)
                    Text(subtitle!, style: const TextStyle(fontSize: 12, color: Colors.grey), maxLines: 1, overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
            if (trailing != null) trailing!
            else if (onTap != null)
              const Icon(Icons.chevron_right, size: 18, color: Colors.grey),
          ],
        ),
      ),
    );
  }
}
