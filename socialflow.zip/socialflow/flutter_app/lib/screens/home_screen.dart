import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../core/api_client.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../widgets/widgets.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final _urlController = TextEditingController();
  final _focusNode = FocusNode();

  bool _isAnalyzing = false;
  bool _isDownloading = false;
  MediaInfo? _mediaInfo;
  MediaQuality? _selectedQuality;
  String? _analyzeError;

  @override
  void dispose() {
    _urlController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  Future<void> _pasteFromClipboard() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text != null && data!.text!.isNotEmpty) {
      _urlController.text = data.text!;
      setState(() {});
    }
  }

  Future<void> _analyze() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please paste a link first')),
      );
      return;
    }

    setState(() {
      _isAnalyzing = true;
      _analyzeError = null;
      _mediaInfo = null;
      _selectedQuality = null;
    });
    _focusNode.unfocus();

    try {
      final json = await ApiClient.instance.analyzeUrl(url);
      setState(() {
        _mediaInfo = MediaInfo.fromJson(json);
        _isAnalyzing = false;
      });
    } on Exception catch (e) {
      String msg = e.toString();
      if (msg.contains('UNSUPPORTED_PLATFORM')) {
        msg = 'This platform is not supported.\nSupported: YouTube, Instagram, TikTok, Facebook, X, Threads, Pinterest, Vimeo, Dailymotion';
      } else if (msg.contains('SocketException') || msg.contains('Connection refused')) {
        msg = 'Cannot connect to backend.\nMake sure the server is running on port 8080.';
      } else {
        msg = 'Could not analyze this link. Please check the URL.';
      }
      setState(() {
        _analyzeError = msg;
        _isAnalyzing = false;
      });
    }
  }

  Future<void> _startDownload() async {
    if (_mediaInfo == null || _selectedQuality == null) return;

    setState(() => _isDownloading = true);

    try {
      await ApiClient.instance.startDownload({
        'url': _mediaInfo!.url,
        'title': _mediaInfo!.title,
        'thumbnail': _mediaInfo!.thumbnail,
        'platform': _mediaInfo!.platform,
        'quality': _selectedQuality!.value,
        'qualityLabel': _selectedQuality!.label,
        'mediaType': _selectedQuality!.type,
      });

      ref.read(downloadsProvider.notifier).load();

      if (!mounted) return;
      setState(() {
        _isDownloading = false;
        _mediaInfo = null;
        _urlController.clear();
        _selectedQuality = null;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Download started!'),
          backgroundColor: const Color(0xFF7C3AED),
          action: SnackBarAction(
            label: 'View',
            textColor: Colors.white,
            onPressed: () {
              // Switch to downloads tab (handled by parent)
              DefaultTabController.maybeOf(context)?.animateTo(1);
            },
          ),
        ),
      );
    } catch (e) {
      setState(() => _isDownloading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Download failed: $e'), backgroundColor: Colors.red),
      );
    }
  }

  void _clearAll() {
    setState(() {
      _mediaInfo = null;
      _urlController.clear();
      _selectedQuality = null;
      _analyzeError = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider);
    final showAds = settings.valueOrNull?.fakeAdsEnabled ?? true;
    final downloads = ref.watch(downloadsProvider);
    final recentDls = downloads.valueOrNull?.take(3).toList() ?? [];

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            floating: true,
            title: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF7C3AED), Color(0xFF06B6D4)],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.download_for_offline, color: Colors.white, size: 20),
                ),
                const SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('SocialFlow', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18)),
                    Text(
                      'Download from any platform',
                      style: TextStyle(fontSize: 11, color: Colors.grey[500]),
                    ),
                  ],
                ),
              ],
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // Premium banner
                if (showAds) ...[
                  _PremiumBanner(),
                  const SizedBox(height: 14),
                ],

                // URL input card
                GlassCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Paste a link to get started',
                        style: TextStyle(fontSize: 12, color: Colors.grey[500]),
                      ),
                      const SizedBox(height: 10),

                      // Input
                      TextField(
                        controller: _urlController,
                        focusNode: _focusNode,
                        keyboardType: TextInputType.url,
                        autocorrect: false,
                        textInputAction: TextInputAction.done,
                        onSubmitted: (_) => _analyze(),
                        decoration: InputDecoration(
                          hintText: 'https://youtube.com/watch?v=...',
                          prefixIcon: const Icon(Icons.link, size: 18),
                          suffixIcon: _urlController.text.isNotEmpty
                              ? IconButton(
                                  icon: const Icon(Icons.cancel, size: 18),
                                  onPressed: _clearAll,
                                )
                              : null,
                          contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
                        ),
                        onChanged: (_) => setState(() {}),
                      ),
                      const SizedBox(height: 10),

                      // Paste + Analyze buttons
                      Row(
                        children: [
                          OutlinedButton.icon(
                            onPressed: _pasteFromClipboard,
                            icon: const Icon(Icons.content_paste, size: 16),
                            label: const Text('Paste'),
                            style: OutlinedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: GradientButton(
                              label: 'Analyze',
                              icon: Icons.search,
                              onPressed: _isAnalyzing ? null : _analyze,
                              loading: _isAnalyzing,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),

                      // Supported platforms
                      _SupportedPlatforms(),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                // Error state
                if (_analyzeError != null)
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEF4444).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.3)),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.error_outline, color: Color(0xFFEF4444), size: 18),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(_analyzeError!, style: const TextStyle(fontSize: 13, height: 1.5)),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close, size: 16),
                          onPressed: () => setState(() => _analyzeError = null),
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                        ),
                      ],
                    ),
                  ),

                // Media info
                if (_mediaInfo != null) ...[
                  _MediaInfoCard(
                    mediaInfo: _mediaInfo!,
                    selectedQuality: _selectedQuality,
                    onSelectQuality: (q) => setState(() => _selectedQuality = q),
                    onDownload: _isDownloading ? null : _startDownload,
                    isDownloading: _isDownloading,
                    onClose: _clearAll,
                  ),
                  const SizedBox(height: 14),
                ],

                // Recent downloads
                if (recentDls.isNotEmpty && _mediaInfo == null) ...[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Recent Downloads', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                      TextButton(
                        onPressed: () {},
                        child: const Text('See all'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  ...recentDls.map((dl) => DownloadCard(download: dl)),
                  const SizedBox(height: 8),
                ],

                // Ad
                if (showAds) ...[
                  const FakeAdBanner(),
                  const SizedBox(height: 16),
                ],
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _PremiumBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [const Color(0xFF7C3AED).withOpacity(0.15), const Color(0xFF06B6D4).withOpacity(0.15)],
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF7C3AED).withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(color: const Color(0xFF7C3AED), borderRadius: BorderRadius.circular(8)),
            child: const Icon(Icons.bolt, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 10),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('SocialFlow Premium', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Color(0xFF7C3AED))),
                Text('Unlimited · Faster · No Ads', style: TextStyle(fontSize: 11, color: Colors.grey)),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              textStyle: const TextStyle(fontSize: 12),
            ),
            child: const Text('Upgrade'),
          ),
        ],
      ),
    );
  }
}

class _SupportedPlatforms extends StatelessWidget {
  static const platforms = [
    ('YouTube', Icons.play_circle_fill, Color(0xFFFF0000)),
    ('Instagram', Icons.camera_alt, Color(0xFFE1306C)),
    ('TikTok', Icons.music_note, Color(0xFFEE1D52)),
    ('Facebook', Icons.facebook, Color(0xFF1877F2)),
    ('X', Icons.tag, Color(0xFF1DA1F2)),
    ('Threads', Icons.alternate_email, Color(0xFFA855F7)),
    ('Pinterest', Icons.push_pin, Color(0xFFE60023)),
    ('Vimeo', Icons.videocam, Color(0xFF1AB7EA)),
    ('DM', Icons.smart_display, Color(0xFF0066DC)),
  ];

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text('Supports:', style: TextStyle(fontSize: 11, color: Colors.grey[500])),
        const SizedBox(width: 8),
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: platforms
                  .map((p) => Container(
                        width: 28,
                        height: 28,
                        margin: const EdgeInsets.only(right: 6),
                        decoration: BoxDecoration(
                          color: p.$3.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: p.$3.withOpacity(0.35)),
                        ),
                        child: Icon(p.$2, size: 14, color: p.$3),
                      ))
                  .toList(),
            ),
          ),
        ),
      ],
    );
  }
}

class _MediaInfoCard extends StatelessWidget {
  final MediaInfo mediaInfo;
  final MediaQuality? selectedQuality;
  final ValueChanged<MediaQuality> onSelectQuality;
  final VoidCallback? onDownload;
  final bool isDownloading;
  final VoidCallback onClose;

  const _MediaInfoCard({
    required this.mediaInfo,
    required this.selectedQuality,
    required this.onSelectQuality,
    required this.onDownload,
    required this.isDownloading,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Thumbnail
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.only(topLeft: Radius.circular(16), topRight: Radius.circular(16)),
                child: mediaInfo.thumbnail.isNotEmpty
                    ? CachedNetworkImage(
                        imageUrl: mediaInfo.thumbnail,
                        width: double.infinity,
                        height: 200,
                        fit: BoxFit.cover,
                        errorWidget: (_, __, ___) => Container(
                          height: 200,
                          color: const Color(0xFF1A1A2E),
                          child: const Icon(Icons.movie, size: 48, color: Colors.grey),
                        ),
                      )
                    : Container(
                        height: 200,
                        color: const Color(0xFF1A1A2E),
                        child: const Icon(Icons.movie, size: 48, color: Colors.grey),
                      ),
              ),
              Positioned(
                top: 8, right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.access_time, size: 10, color: Colors.white),
                      const SizedBox(width: 3),
                      Text(mediaInfo.duration, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 8, left: 8,
                child: GestureDetector(
                  onTap: onClose,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(6)),
                    child: const Icon(Icons.close, size: 14, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),

          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                PlatformBadge(platform: mediaInfo.platform),
                const SizedBox(height: 6),
                Text(mediaInfo.title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, height: 1.4), maxLines: 3, overflow: TextOverflow.ellipsis),
                if (mediaInfo.uploader != null || mediaInfo.viewCount != null) ...[
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 12,
                    children: [
                      if (mediaInfo.uploader != null)
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.person, size: 12, color: Colors.grey),
                          const SizedBox(width: 3),
                          Text(mediaInfo.uploader!, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                        ]),
                      if (mediaInfo.viewCount != null)
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.visibility, size: 12, color: Colors.grey),
                          const SizedBox(width: 3),
                          Text('${(mediaInfo.viewCount! / 1000).toStringAsFixed(0)}K views', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                        ]),
                    ],
                  ),
                ],

                // Video qualities
                if (mediaInfo.videoQualities.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Row(children: [const Icon(Icons.videocam, size: 13, color: Colors.grey), const SizedBox(width: 4), Text('Video', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Colors.grey[600], letterSpacing: 0.5))]),
                  const SizedBox(height: 7),
                  Wrap(
                    spacing: 7,
                    runSpacing: 7,
                    children: mediaInfo.videoQualities.map((q) {
                      final sel = selectedQuality?.value == q.value;
                      return GestureDetector(
                        onTap: () => onSelectQuality(q),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 150),
                          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                          decoration: BoxDecoration(
                            color: sel ? const Color(0xFF7C3AED) : Theme.of(context).colorScheme.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: sel ? const Color(0xFF7C3AED) : Colors.grey.withOpacity(0.3)),
                          ),
                          child: Column(
                            children: [
                              Text(q.label, style: TextStyle(color: sel ? Colors.white : null, fontSize: 12, fontWeight: FontWeight.w600)),
                              Text(q.fileSize, style: TextStyle(color: sel ? Colors.white70 : Colors.grey, fontSize: 10)),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],

                // Audio qualities
                if (mediaInfo.audioQualities.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Row(children: [const Icon(Icons.music_note, size: 13, color: Colors.grey), const SizedBox(width: 4), Text('Audio Only', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Colors.grey[600], letterSpacing: 0.5))]),
                  const SizedBox(height: 7),
                  Wrap(
                    spacing: 7,
                    runSpacing: 7,
                    children: mediaInfo.audioQualities.map((q) {
                      final sel = selectedQuality?.value == q.value;
                      return GestureDetector(
                        onTap: () => onSelectQuality(q),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 150),
                          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                          decoration: BoxDecoration(
                            color: sel ? const Color(0xFF06B6D4) : Theme.of(context).colorScheme.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: sel ? const Color(0xFF06B6D4) : Colors.grey.withOpacity(0.3)),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.music_note, size: 11, color: sel ? Colors.white : Colors.grey),
                              const SizedBox(width: 4),
                              Column(children: [
                                Text(q.label, style: TextStyle(color: sel ? Colors.white : null, fontSize: 12, fontWeight: FontWeight.w600)),
                                Text(q.fileSize, style: TextStyle(color: sel ? Colors.white70 : Colors.grey, fontSize: 10)),
                              ]),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],

                const SizedBox(height: 14),
                GradientButton(
                  label: selectedQuality != null ? 'Download ${selectedQuality!.label}' : 'Select Quality First',
                  icon: Icons.download,
                  onPressed: (selectedQuality != null && onDownload != null) ? onDownload : null,
                  loading: isDownloading,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
