import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../widgets/widgets.dart';

class DownloadsScreen extends ConsumerStatefulWidget {
  const DownloadsScreen({super.key});

  @override
  ConsumerState<DownloadsScreen> createState() => _DownloadsScreenState();
}

class _DownloadsScreenState extends ConsumerState<DownloadsScreen> {
  String _filter = 'all';

  static const _filters = [
    ('all', 'All'),
    ('active', 'Active'),
    ('completed', 'Done'),
    ('failed', 'Failed'),
  ];

  List<DownloadItem> _applyFilter(List<DownloadItem> list) {
    switch (_filter) {
      case 'active':
        return list.where((d) => d.isActive).toList();
      case 'completed':
        return list.where((d) => d.status == 'completed').toList();
      case 'failed':
        return list.where((d) => d.status == 'failed' || d.status == 'cancelled').toList();
      default:
        return list;
    }
  }

  int _countFor(String f, List<DownloadItem> list) {
    switch (f) {
      case 'active':
        return list.where((d) => d.isActive).length;
      case 'completed':
        return list.where((d) => d.status == 'completed').length;
      case 'failed':
        return list.where((d) => d.status == 'failed' || d.status == 'cancelled').length;
      default:
        return list.length;
    }
  }

  void _confirmClearAll() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear History'),
        content: const Text('Delete all download records?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              ref.read(downloadsProvider.notifier).clearAll();
            },
            child: const Text('Clear All', style: TextStyle(color: Color(0xFFEF4444))),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final downloadsAsync = ref.watch(downloadsProvider);

    return Scaffold(
      appBar: AppBar(
        title: downloadsAsync.when(
          data: (list) {
            final active = list.where((d) => d.isActive).length;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Downloads', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 22)),
                if (active > 0)
                  Text('$active active', style: const TextStyle(fontSize: 12, color: Color(0xFF06B6D4))),
              ],
            );
          },
          loading: () => const Text('Downloads', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 22)),
          error: (_, __) => const Text('Downloads', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 22)),
        ),
        actions: [
          if (downloadsAsync.valueOrNull?.isNotEmpty == true)
            IconButton(
              onPressed: _confirmClearAll,
              icon: const Icon(Icons.delete_sweep_outlined, color: Color(0xFFEF4444)),
              tooltip: 'Clear all',
            ),
        ],
      ),
      body: downloadsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.wifi_off, size: 48, color: Colors.grey),
              const SizedBox(height: 12),
              const Text('Cannot connect to backend', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              const Text('Make sure the server is running', style: TextStyle(color: Colors.grey, fontSize: 13)),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () => ref.read(downloadsProvider.notifier).load(),
                icon: const Icon(Icons.refresh),
                label: const Text('Retry'),
              ),
            ],
          ),
        ),
        data: (all) {
          final filtered = _applyFilter(all);
          return Column(
            children: [
              // Filter chips
              SizedBox(
                height: 44,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  children: _filters.map((f) {
                    final isActive = _filter == f.$1;
                    final count = _countFor(f.$1, all);
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GestureDetector(
                        onTap: () => setState(() => _filter = f.$1),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 150),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: isActive ? const Color(0xFF7C3AED) : Theme.of(context).colorScheme.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: isActive ? const Color(0xFF7C3AED) : Colors.grey.withOpacity(0.3),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                f.$2,
                                style: TextStyle(
                                  color: isActive ? Colors.white : null,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13,
                                ),
                              ),
                              if (count > 0) ...[
                                const SizedBox(width: 5),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                                  decoration: BoxDecoration(
                                    color: isActive ? Colors.white24 : Colors.grey.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    '$count',
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                      color: isActive ? Colors.white : null,
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),

              // List
              Expanded(
                child: filtered.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 72,
                              height: 72,
                              decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: const Icon(Icons.download_for_offline_outlined, size: 32, color: Colors.grey),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              _filter == 'all' ? 'No Downloads Yet' : 'No ${_filter} downloads',
                              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 17),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _filter == 'all'
                                  ? 'Go to Home tab and paste a link to start'
                                  : 'Switch to "All" to see everything',
                              style: const TextStyle(color: Colors.grey, fontSize: 13),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      )
                    : RefreshIndicator(
                        onRefresh: () => ref.read(downloadsProvider.notifier).load(),
                        child: ListView.builder(
                          padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                          itemCount: filtered.length,
                          itemBuilder: (ctx, i) {
                            final dl = filtered[i];
                            return DownloadCard(
                              download: dl,
                              onPause: dl.status == 'downloading'
                                  ? () => ref.read(downloadsProvider.notifier).updateAction(dl.id, 'pause')
                                  : null,
                              onResume: dl.status == 'paused'
                                  ? () => ref.read(downloadsProvider.notifier).updateAction(dl.id, 'resume')
                                  : null,
                              onCancel: dl.isActive
                                  ? () => ref.read(downloadsProvider.notifier).updateAction(dl.id, 'cancel')
                                  : null,
                              onRetry: (dl.status == 'failed' || dl.status == 'cancelled')
                                  ? () => ref.read(downloadsProvider.notifier).updateAction(dl.id, 'retry')
                                  : null,
                              onDelete: () => ref.read(downloadsProvider.notifier).delete(dl.id),
                            );
                          },
                        ),
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
