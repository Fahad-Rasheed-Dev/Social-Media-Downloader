import 'package:dio/dio.dart';

class ApiClient {
  static ApiClient? _instance;
  late final Dio _dio;

  // Change this to your backend URL:
  // - Android Emulator: http://10.0.2.2:8080
  // - Physical Device (same WiFi): http://<YOUR_PC_IP>:8080
  // - iOS Simulator: http://localhost:8080
  static String baseUrl = 'http://10.0.2.2:8080';

  ApiClient._() {
    _dio = Dio(BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 30),
      headers: {'Content-Type': 'application/json'},
    ));

    _dio.interceptors.add(LogInterceptor(
      requestBody: true,
      responseBody: false,
      error: true,
    ));
  }

  static ApiClient get instance => _instance ??= ApiClient._();

  static void setBaseUrl(String url) {
    baseUrl = url;
    _instance = null; // force re-create
  }

  // ─── Health ────────────────────────────────────────────────────────────────
  Future<bool> healthCheck() async {
    try {
      final res = await _dio.get('/api/healthz');
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  // ─── Analyze ───────────────────────────────────────────────────────────────
  Future<Map<String, dynamic>> analyzeUrl(String url) async {
    final res = await _dio.post('/api/analyze', data: {'url': url});
    return res.data as Map<String, dynamic>;
  }

  // ─── Downloads ─────────────────────────────────────────────────────────────
  Future<Map<String, dynamic>> startDownload(Map<String, dynamic> payload) async {
    final res = await _dio.post('/api/download', data: payload);
    return res.data as Map<String, dynamic>;
  }

  Future<List<dynamic>> listDownloads({String? status}) async {
    final params = status != null ? {'status': status} : null;
    final res = await _dio.get('/api/downloads', queryParameters: params);
    return res.data as List<dynamic>;
  }

  Future<Map<String, dynamic>> updateDownload(String id, Map<String, dynamic> payload) async {
    final res = await _dio.patch('/api/downloads/$id', data: payload);
    return res.data as Map<String, dynamic>;
  }

  Future<void> deleteDownload(String id) async {
    await _dio.delete('/api/downloads/$id');
  }

  Future<void> clearDownloads() async {
    await _dio.delete('/api/downloads');
  }

  // ─── Settings ──────────────────────────────────────────────────────────────
  Future<Map<String, dynamic>> getSettings() async {
    final res = await _dio.get('/api/settings');
    return res.data as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> updateSettings(Map<String, dynamic> payload) async {
    final res = await _dio.put('/api/settings', data: payload);
    return res.data as Map<String, dynamic>;
  }
}
