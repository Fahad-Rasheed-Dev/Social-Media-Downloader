class MediaQuality {
  final String label;
  final String value;
  final String fileSize;
  final String type; // 'video' or 'audio'

  const MediaQuality({
    required this.label,
    required this.value,
    required this.fileSize,
    required this.type,
  });

  factory MediaQuality.fromJson(Map<String, dynamic> j) => MediaQuality(
        label: j['label'] as String,
        value: j['value'] as String,
        fileSize: j['fileSize'] as String,
        type: j['type'] as String,
      );
}

class MediaInfo {
  final String url;
  final String title;
  final String thumbnail;
  final String duration;
  final String platform;
  final String? uploader;
  final int? viewCount;
  final List<MediaQuality> qualities;

  const MediaInfo({
    required this.url,
    required this.title,
    required this.thumbnail,
    required this.duration,
    required this.platform,
    this.uploader,
    this.viewCount,
    required this.qualities,
  });

  factory MediaInfo.fromJson(Map<String, dynamic> j) => MediaInfo(
        url: j['url'] as String,
        title: j['title'] as String,
        thumbnail: j['thumbnail'] as String? ?? '',
        duration: j['duration'] as String,
        platform: j['platform'] as String,
        uploader: j['uploader'] as String?,
        viewCount: j['viewCount'] as int?,
        qualities: (j['qualities'] as List<dynamic>)
            .map((q) => MediaQuality.fromJson(q as Map<String, dynamic>))
            .toList(),
      );

  List<MediaQuality> get videoQualities => qualities.where((q) => q.type == 'video').toList();
  List<MediaQuality> get audioQualities => qualities.where((q) => q.type == 'audio').toList();
}

class DownloadItem {
  final String id;
  final String url;
  final String title;
  final String thumbnail;
  final String platform;
  final String quality;
  final String qualityLabel;
  final String mediaType;
  final String status;
  final double progress;
  final String? filePath;
  final String? fileSize;
  final String? errorMessage;
  final String createdAt;
  final String updatedAt;

  const DownloadItem({
    required this.id,
    required this.url,
    required this.title,
    required this.thumbnail,
    required this.platform,
    required this.quality,
    required this.qualityLabel,
    required this.mediaType,
    required this.status,
    required this.progress,
    this.filePath,
    this.fileSize,
    this.errorMessage,
    required this.createdAt,
    required this.updatedAt,
  });

  factory DownloadItem.fromJson(Map<String, dynamic> j) => DownloadItem(
        id: j['id'] as String,
        url: j['url'] as String,
        title: j['title'] as String,
        thumbnail: j['thumbnail'] as String? ?? '',
        platform: j['platform'] as String? ?? '',
        quality: j['quality'] as String? ?? '',
        qualityLabel: j['qualityLabel'] as String? ?? '',
        mediaType: j['mediaType'] as String? ?? 'video',
        status: j['status'] as String,
        progress: (j['progress'] as num).toDouble(),
        filePath: j['filePath'] as String?,
        fileSize: j['fileSize'] as String?,
        errorMessage: j['errorMessage'] as String?,
        createdAt: j['createdAt'] as String,
        updatedAt: j['updatedAt'] as String,
      );

  bool get isActive => status == 'downloading' || status == 'paused' || status == 'pending';

  DownloadItem copyWith({String? status, double? progress, String? filePath, String? fileSize}) =>
      DownloadItem(
        id: id, url: url, title: title, thumbnail: thumbnail,
        platform: platform, quality: quality, qualityLabel: qualityLabel,
        mediaType: mediaType,
        status: status ?? this.status,
        progress: progress ?? this.progress,
        filePath: filePath ?? this.filePath,
        fileSize: fileSize ?? this.fileSize,
        errorMessage: errorMessage,
        createdAt: createdAt,
        updatedAt: updatedAt,
      );
}

class AppSettings {
  final String theme;
  final String language;
  final String downloadFolder;
  final int autoDeleteDays;
  final bool notificationsEnabled;
  final bool fakeAdsEnabled;
  final String defaultQuality;

  const AppSettings({
    this.theme = 'system',
    this.language = 'en',
    this.downloadFolder = '',
    this.autoDeleteDays = 0,
    this.notificationsEnabled = true,
    this.fakeAdsEnabled = true,
    this.defaultQuality = '720p',
  });

  factory AppSettings.fromJson(Map<String, dynamic> j) => AppSettings(
        theme: j['theme'] as String? ?? 'system',
        language: j['language'] as String? ?? 'en',
        downloadFolder: j['downloadFolder'] as String? ?? '',
        autoDeleteDays: j['autoDeleteDays'] as int? ?? 0,
        notificationsEnabled: j['notificationsEnabled'] as bool? ?? true,
        fakeAdsEnabled: j['fakeAdsEnabled'] as bool? ?? true,
        defaultQuality: j['defaultQuality'] as String? ?? '720p',
      );

  Map<String, dynamic> toJson() => {
        'theme': theme,
        'language': language,
        'downloadFolder': downloadFolder,
        'autoDeleteDays': autoDeleteDays,
        'notificationsEnabled': notificationsEnabled,
        'fakeAdsEnabled': fakeAdsEnabled,
        'defaultQuality': defaultQuality,
      };

  AppSettings copyWith({
    String? theme, String? language, String? downloadFolder,
    int? autoDeleteDays, bool? notificationsEnabled,
    bool? fakeAdsEnabled, String? defaultQuality,
  }) => AppSettings(
    theme: theme ?? this.theme,
    language: language ?? this.language,
    downloadFolder: downloadFolder ?? this.downloadFolder,
    autoDeleteDays: autoDeleteDays ?? this.autoDeleteDays,
    notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
    fakeAdsEnabled: fakeAdsEnabled ?? this.fakeAdsEnabled,
    defaultQuality: defaultQuality ?? this.defaultQuality,
  );
}
