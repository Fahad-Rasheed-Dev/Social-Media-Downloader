import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/api_client.dart';
import '../models/models.dart';

// ─── Theme ────────────────────────────────────────────────────────────────────

class ThemeNotifier extends StateNotifier<ThemeMode> {
  ThemeNotifier() : super(ThemeMode.system) {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final val = prefs.getString('theme') ?? 'system';
    state = _fromString(val);
  }

  Future<void> setTheme(String val) async {
    state = _fromString(val);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme', val);
  }

  ThemeMode _fromString(String v) {
    if (v == 'light') return ThemeMode.light;
    if (v == 'dark') return ThemeMode.dark;
    return ThemeMode.system;
  }

  String get currentString {
    if (state == ThemeMode.light) return 'light';
    if (state == ThemeMode.dark) return 'dark';
    return 'system';
  }
}

final themeProvider = StateNotifierProvider<ThemeNotifier, ThemeMode>((ref) => ThemeNotifier());

// ─── Backend URL ──────────────────────────────────────────────────────────────

class BackendUrlNotifier extends StateNotifier<String> {
  BackendUrlNotifier() : super(ApiClient.baseUrl) {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('backendUrl');
    if (saved != null && saved.isNotEmpty) {
      state = saved;
      ApiClient.setBaseUrl(saved);
    }
  }

  Future<void> setUrl(String url) async {
    state = url;
    ApiClient.setBaseUrl(url);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('backendUrl', url);
  }
}

final backendUrlProvider = StateNotifierProvider<BackendUrlNotifier, String>(
  (ref) => BackendUrlNotifier(),
);

// ─── Settings ─────────────────────────────────────────────────────────────────

class SettingsNotifier extends StateNotifier<AsyncValue<AppSettings>> {
  SettingsNotifier() : super(const AsyncValue.loading()) {
    load();
  }

  Future<void> load() async {
    try {
      final json = await ApiClient.instance.getSettings();
      state = AsyncValue.data(AppSettings.fromJson(json));
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  Future<void> update(AppSettings s) async {
    try {
      final json = await ApiClient.instance.updateSettings(s.toJson());
      state = AsyncValue.data(AppSettings.fromJson(json));
    } catch (_) {}
  }
}

final settingsProvider = StateNotifierProvider<SettingsNotifier, AsyncValue<AppSettings>>(
  (ref) => SettingsNotifier(),
);

// ─── Downloads ────────────────────────────────────────────────────────────────

class DownloadsNotifier extends StateNotifier<AsyncValue<List<DownloadItem>>> {
  DownloadsNotifier() : super(const AsyncValue.loading()) {
    load();
    _startPolling();
  }

  Timer? _timer;

  void _startPolling() {
    _timer = Timer.periodic(const Duration(seconds: 2), (_) => load());
  }

  Future<void> load() async {
    try {
      final list = await ApiClient.instance.listDownloads();
      state = AsyncValue.data(
        list.map((e) => DownloadItem.fromJson(e as Map<String, dynamic>)).toList(),
      );
    } catch (e, st) {
      if (state is! AsyncData) {
        state = AsyncValue.error(e, st);
      }
    }
  }

  Future<void> updateAction(String id, String action) async {
    try {
      await ApiClient.instance.updateDownload(id, {'action': action});
      await load();
    } catch (_) {}
  }

  Future<void> delete(String id) async {
    try {
      await ApiClient.instance.deleteDownload(id);
      await load();
    } catch (_) {}
  }

  Future<void> clearAll() async {
    try {
      await ApiClient.instance.clearDownloads();
      await load();
    } catch (_) {}
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}

final downloadsProvider = StateNotifierProvider<DownloadsNotifier, AsyncValue<List<DownloadItem>>>(
  (ref) => DownloadsNotifier(),
);
